# disabledAttrs
Disable attributes for all field types.

## Usage
```javascript
var options = {
  disabledAttrs: [
    'name'
  ]
};
$(container).formBuilder(options);
```
<p data-height="525" data-embed-version="2" data-theme-id="22927" data-slug-hash="NjLGyN" data-default-tab="js,result" data-user="kevinchappell" class="codepen"></p>
