A Pen created at CodePen.io. You can find this one at https://codepen.io/mephysto/pen/ZYVKRY.

 Here's a way to iterate through multiple items in one slide in bootstrap 3.3.x

But tbh, you're better off using something like Owl Carousel...